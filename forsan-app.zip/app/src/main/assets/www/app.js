/* ============================================================
   فرسان المعرفة — منطق التطبيق
   أسماء الشاشات s1 … s13 تطابق أرقام شرائح البوربوينت،
   وأسماء العناصر تطابق أسماءها في الشرائح (dokol, txtname, sss1 …).
   ============================================================ */
(function () {
  'use strict';

  var RATIO = 6911975 / 3887788;             // نسبة الشريحة (الطول ÷ العرض)
  var API = String(window.FORSAN_API || '').trim();
  var ZWJ = '‍';

  function $(id) { return document.getElementById(id); }

  // ---------------------------------------------------------------- الحالة
  var S = {
    current: null,
    user: null,          // { name: nameacount1, fars: txtnamefars }
    rasid: null,         // { asilah, takiimat, takim2, majmo }
    data: { questions: [], lessons: [], benefits: [], leaders: [] },
    loaded: false,       // وصلت البيانات (من الخادم أو من النسخة المحفوظة)
    bootError: null,
    busy: false,
    lastTap: 0,
    quiz: { deck: [], last: -1, cur: null, newrasi: 0, newrasir: 0, dirty: false, lock: false, timer: 0 },
    selBenefit: null,
    selLesson: null,
    ismdars: null,
    drafts: {}
  };

  // ---------------------------------------------------------------- تخزين محلي آمن
  function load(key) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch (e) { return null; }
  }
  function store(key, val) {
    try { if (val === null) localStorage.removeItem(key); else localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* لا شيء */ }
  }

  // ---------------------------------------------------------------- أدوات
  function num(v) {
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var s = String(v == null ? '' : v).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); })
      .replace(/[^\d.\-]/g, '');
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  // تصغير الخط حتى يتسع النص لمربعه
  function fitText(el, minRatio) {
    el.style.fontSize = '';
    var base = parseFloat(getComputedStyle(el).fontSize) || 16;
    var size = base, min = base * (minRatio || 0.55);
    var guard = 0;
    while ((el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) && size > min && guard++ < 40) {
      size = size * 0.93;
      el.style.fontSize = size + 'px';
    }
  }

  // ---------------------------------------------------------------- مقاس الشاشة ولوحة المفاتيح
  var stable = { w: 0, h: 0 }, kbJava = 0, kbResize = 0, shiftNow = 0;

  function typingEl() {
    var a = document.activeElement;
    return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') ? a : null;
  }

  function measure() {
    var w = window.innerWidth, h = window.innerHeight;
    if (!w || !h) return;
    // إذا صغر ارتفاع النافذة بسبب لوحة المفاتيح فلا نصغّر التصميم، بل نرفع الخانة فقط
    if (typingEl() && stable.w && w === stable.w && h < stable.h) {
      kbResize = stable.h - h; updateShift(); return;
    }
    kbResize = 0;
    stable = { w: w, h: h };
    var app = $('app');
    app.style.width = w + 'px'; app.style.height = h + 'px';
    var sw = w, sh = w * RATIO;
    if (sh > h) { sh = h; sw = h / RATIO; }
    var st = $('stage');
    st.style.width = sw + 'px'; st.style.height = sh + 'px';
    st.style.left = ((w - sw) / 2) + 'px'; st.style.top = ((h - sh) / 2) + 'px';
    document.documentElement.style.setProperty('--u', (sw / 100) + 'px');
    updateShift();
    refitCurrent();
  }

  function updateShift() {
    var a = typingEl(), app = $('app');
    var kb = Math.max(kbJava, kbResize);
    if (!a || kb <= 0) { shiftNow = 0; app.style.transform = ''; return; }
    var stTop = parseFloat($('stage').style.top) || 0;
    var top = stTop + a.offsetTop, bottom = top + a.offsetHeight;
    var visible = stable.h - kb, margin = stable.h * 0.03;
    var shift = 0;
    if (bottom + margin > visible) shift = bottom + margin - visible;
    shift = Math.max(0, Math.min(shift, top - margin));   // لا نخفي أعلى الخانة
    shiftNow = shift;
    app.style.transform = shift ? 'translateY(' + (-shift) + 'px)' : '';
  }

  // يستدعيها غلاف أندرويد كلما ظهرت لوحة المفاتيح أو اختفت (بالبكسل)
  window.__forsanKeyboard = function (px) { kbJava = Math.max(0, +px || 0); updateShift(); };

  document.addEventListener('focusin', function () { setTimeout(updateShift, 60); setTimeout(updateShift, 350); });
  document.addEventListener('focusout', function () { setTimeout(updateShift, 80); });
  window.addEventListener('resize', measure);

  // ---------------------------------------------------------------- التنقل بين الشاشات
  var ENTER = {};

  function go(id) {
    var next = $(id);
    if (!next || S.current === id) return;
    var a = typingEl(); if (a) a.blur();
    if (S.current) {
      var prev = $(S.current);
      prev.classList.remove('visible', 'shown');
    }
    S.current = id;
    var top = next.getAttribute('data-edge-top'), bottom = next.getAttribute('data-edge-bottom');
    document.body.style.background = 'linear-gradient(180deg,' + top + ' 50%,' + bottom + ' 50%)';
    next.classList.add('shown');
    void next.offsetWidth;            // لبدء حركة الظهور
    next.classList.add('visible');
    if (ENTER[id]) ENTER[id]();
  }

  function refitCurrent() {
    var id = S.current;
    if (!id) return;
    var els = $(id).querySelectorAll('.txt');
    for (var i = 0; i < els.length; i++) {
      if (els[i].id === 's4-txtfares') fitFares();
      else if (els[i].classList.contains('question')) fitText(els[i], 0.6);
      else if (els[i].textContent) fitText(els[i], 0.5);
    }
  }

  // ---------------------------------------------------------------- الرسائل ومؤشر الانتظار
  var msgQueue = [], msgOpen = false;
  function msg(text) {
    return new Promise(function (resolve) {
      msgQueue.push({ text: text, resolve: resolve });
      if (!msgOpen) nextMsg();
    });
  }
  function nextMsg() {
    var m = msgQueue.shift();
    if (!m) { msgOpen = false; $('msg').hidden = true; return; }
    msgOpen = true;
    $('msg-text').textContent = m.text;
    $('msg').hidden = false;
    $('msg').__resolve = m.resolve;
  }
  function closeMsg() {
    var r = $('msg').__resolve; $('msg').__resolve = null;
    if (r) r();
    nextMsg();
  }
  $('msg-ok').addEventListener('click', function (e) { e.stopPropagation(); closeMsg(); });

  var busyTimer = 0;
  function setBusy(on) {
    S.busy = on;
    clearTimeout(busyTimer);
    if (on) busyTimer = setTimeout(function () { $('busy').hidden = false; }, 250);  // لا يظهر للردود السريعة
    else $('busy').hidden = true;
  }

  // ---------------------------------------------------------------- الاتصال بقاعدة البيانات (Google Sheets)
  function api(action, payload, opts) {
    opts = opts || {};
    if (!/^https:\/\//.test(API)) return Promise.reject({ code: 'noapi' });
    if (opts.busy) setBusy(true);
    var body = { action: action };
    for (var k in (payload || {})) body[k] = payload[k];
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 30000);
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(body),
      redirect: 'follow',
      cache: 'no-store',
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (res) { return res.text(); })
      .then(function (txt) {
        try { return JSON.parse(txt); } catch (e) { throw { code: 'badjson' }; }
      })
      .catch(function (err) { throw (err && err.code) ? err : { code: 'net' }; })
      .then(function (r) { clearTimeout(timer); if (opts.busy) setBusy(false); return r; },
        function (e) { clearTimeout(timer); if (opts.busy) setBusy(false); throw e; });
  }

  function errText(e) {
    if (e && e.code === 'noapi') return 'لم يُضبط رابط قاعدة البيانات داخل التطبيق بعد.';
    if (e && e.code === 'badjson') return 'وصل رد غير مفهوم من قاعدة البيانات.\nتأكد أن السكربت منشور بصلاحية «أي شخص».';
    if (e && e.code === 'server') return 'حدث خطأ في قاعدة البيانات:\n' + (e.msg || '');
    return 'تعذّر الاتصال بقاعدة البيانات.\nتأكد من اتصالك بالإنترنت ثم أعد المحاولة.\nوإن تكرر ذلك مع وجود الإنترنت، فتأكد أن السكربت منشور بصلاحية «أي شخص».';
  }

  // تحميل الأسئلة والدروس والفوائد مسبقًا حتى تُعرض فورًا دون انتظار
  function applyData(r) {
    if (r.questions) S.data.questions = r.questions;
    if (r.lessons) S.data.lessons = r.lessons;
    if (r.benefits) S.data.benefits = r.benefits;
    if (r.leaders) S.data.leaders = r.leaders;
    S.loaded = true;
    store('forsan.data', S.data);
  }

  function boot() {
    var cached = load('forsan.data');
    if (cached && cached.questions) { S.data = cached; S.loaded = true; }
    return api('boot').then(function (r) {
      if (!r.ok) throw { code: 'server', msg: r.msg };
      S.bootError = null;
      applyData(r);
      dataChanged();
    }).catch(function (e) {
      S.bootError = e;
      dataChanged();
    }).then(flushScore);
  }

  function dataChanged() {
    if (S.current === 's5' && !S.quiz.cur) nextQuestion();
    if (S.current === 's6') renderLeaders();
    if (S.current === 's9') renderBenefits();
    if (S.current === 's12') renderLessons();
  }

  function refreshRasid() {
    if (!S.user) return Promise.resolve();
    return api('rasid', { name: S.user.name }).then(function (r) {
      if (r.ok) {
        if (r.rasid) S.rasid = r.rasid;
        if (r.leaders) { S.data.leaders = r.leaders; store('forsan.data', S.data); }
      }
    }).catch(function () { /* نكتفي بالبيانات الموجودة */ });
  }

  // ---------------------------------------------------------------- الأصوات
  var SND = { ctx: null, buf: {} };
  function initAudio() {
    if (SND.ctx) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { SND.ctx = new AC(); } catch (e) { return; }
    ['sotsah', 'sotkat'].forEach(function (n) {
      fetch('snd/' + n + '.wav').then(function (r) { return r.arrayBuffer(); }).then(function (b) {
        SND.ctx.decodeAudioData(b, function (buf) { SND.buf[n] = buf; }, function () { });
      }).catch(function () { });
    });
  }
  function play(n) {
    try {
      if (!SND.ctx) initAudio();
      if (SND.ctx && SND.ctx.state === 'suspended') SND.ctx.resume();
      var b = SND.buf[n];
      if (!SND.ctx || !b) { var a = new Audio('snd/' + n + '.wav'); a.play().catch(function () { }); return; }
      var s = SND.ctx.createBufferSource(); s.buffer = b; s.connect(SND.ctx.destination); s.start(0);
    } catch (e) { /* لا شيء */ }
  }
  document.addEventListener('pointerdown', initAudio, { once: true });
  document.addEventListener('touchstart', initAudio, { once: true });

  // ---------------------------------------------------------------- الخروج من التطبيق
  function exitApp() {
    if (window.Android && Android.exitApp) Android.exitApp();
    else window.close();
  }

  // ---------------------------------------------------------------- الجلسة
  function startSession(r) {
    S.user = { name: r.name, fars: r.fars };               // nameacount1 و txtnamefars
    S.rasid = r.rasid || { asilah: 0, takiimat: 0, takim2: 0, majmo: 0 };
    if (r.leaders) S.data.leaders = r.leaders;
    store('forsan.lastName', r.name);
    flushScore();
  }
  function logout() {
    saveQuizIfBetter();
    S.user = null; S.rasid = null;
    $('s2-txtpas').value = '';
    go('s2');
  }

  // ================================================================ شريحة 1 و 2: الدخول
  function validName(n) {
    return Array.from(n).length <= 10 && !/\s/.test(n) && !/^[=+\-–—−]/.test(n);
  }

  function doLogin() {
    var name = $('s2-txtname').value.trim();
    var pas = $('s2-txtpas').value;
    if (!name) return msg('إن كان عندك اسم حساب فاكتبه، وإلا فأنشئ حسابًا جديدًا من الصفحة الرئيسية');
    api('login', { name: name, pas: pas }, { busy: true }).then(function (r) {
      if (!r.ok) {
        if (r.code === 'nouser') return msg('لا يوجد حساب مسجل بهذا الاسم');
        if (r.code === 'nopass') return msg('يجب إدخال كلمة مرور');
        if (r.code === 'badpass') return msg('كلمة المرور غير صحيحة');
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      startSession(r);
      $('s2-txtpas').value = '';
      go('s4');
    }, function (e) { msg(errText(e)); });
  }

  ENTER.s2 = function () {
    var last = load('forsan.lastName');
    if (last && !$('s2-txtname').value) $('s2-txtname').value = last;
  };

  // ================================================================ شريحة 3: إنشاء حساب
  function doRegister() {
    var name = $('s3-txtnameac').value.trim();
    var fars = $('s3-txtnamefars').value.trim();
    var pas = $('s3-txtpas').value;
    if (!name || !fars || !pas) return msg('تأكد من ملء جميع الخانات قبل الاستمرار');
    if (!validName(name)) return msg('لا يمكن التسمية بهذا الاسم، اختر اسمًا مناسبًا');
    api('register', { name: name, fars: fars, pas: pas }, { busy: true }).then(function (r) {
      if (!r.ok) {
        if (r.code === 'exists') return msg('الاسم موجود، يمكنك تسجيل الدخول إذا كنت صاحب الحساب، أو اختر اسمًا آخر');
        if (r.code === 'badname') return msg('لا يمكن التسمية بهذا الاسم، اختر اسمًا مناسبًا');
        if (r.code === 'empty') return msg('تأكد من ملء جميع الخانات قبل الاستمرار');
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      startSession(r);
      $('s3-txtnameac').value = ''; $('s3-txtnamefars').value = ''; $('s3-txtpas').value = '';
      $('s2-txtname').value = r.name;
      go('s4');
      msg('أُنشِئ حساب الفارس بنجاح');
    }, function (e) { msg(errText(e)); });
  }

  // ================================================================ شريحة 4: قائمة الفارس
  // تقسيم النص العربي إلى حروف مع المحافظة على اتصالها، حتى يقفز كل حرف وحده
  var RIGHT_ONLY = 'اأإآٱدذرزوؤةژڈڑ';
  function joinType(ch) {
    if (!ch) return 'U';
    if (ch === 'ء') return 'U';
    if (ch === 'ـ') return 'C';
    if (RIGHT_ONLY.indexOf(ch) >= 0) return 'R';
    var c = ch.charCodeAt(0);
    if ((c >= 0x0620 && c <= 0x064A) || (c >= 0x066E && c <= 0x06D3) || c === 0x06D5 || (c >= 0x06EE && c <= 0x06FF)) return 'D';
    return 'U';
  }
  function isMark(ch) {
    var c = ch.charCodeAt(0);
    return (c >= 0x064B && c <= 0x065F) || c === 0x0670 || (c >= 0x06D6 && c <= 0x06DC) ||
      (c >= 0x06DF && c <= 0x06E4) || c === 0x06E7 || c === 0x06E8 || (c >= 0x06EA && c <= 0x06ED);
  }
  function clusters(text) {
    var out = [], chars = Array.from(text);
    for (var i = 0; i < chars.length; i++) {
      var ch = chars[i];
      if (isMark(ch) && out.length) { out[out.length - 1].t += ch; continue; }
      out.push({ t: ch, b: ch, last: ch });
    }
    // لام ألف تبقى مجتمعة
    var merged = [];
    for (var j = 0; j < out.length; j++) {
      var cur = out[j], nx = out[j + 1];
      if (cur.b === 'ل' && nx && 'اأإآٱ'.indexOf(nx.b) >= 0) {
        merged.push({ t: cur.t + nx.t, b: 'ل', last: nx.b }); j++;
      } else merged.push(cur);
    }
    return merged.map(function (c) {
      var first = joinType(c.b), last = joinType(c.last);
      return { t: c.t, joinPrev: first === 'D' || first === 'R' || first === 'C', joinNext: last === 'D' || last === 'C' };
    });
  }
  function bounceText(el, text) {
    el.innerHTML = '';
    var LATIN = /[A-Za-zÀ-ɏ]/, ARABIC = /[؀-ۿ]/;
    // اتجاه السطر بحسب أول حرف: عربي ← من اليمين، لاتيني ← من اليسار
    var firstStrong = (text.match(/[A-Za-zÀ-ɏ؀-ۿ]/) || [''])[0];
    var rtl = !LATIN.test(firstStrong);
    el.style.direction = rtl ? 'rtl' : 'ltr';
    var n = 0;
    function add(t) {
      var s = document.createElement('span');
      s.className = 'ch';
      s.textContent = t;
      s.style.animationDelay = (n++ * 0.11) + 's';
      el.appendChild(s);
    }
    String(text || '').split(/(\s+)/).forEach(function (w) {
      if (!w) return;
      if (/^\s+$/.test(w)) { add(' '); return; }
      var arabic = ARABIC.test(w);
      if (arabic && rtl) {
        var cs = clusters(w);
        cs.forEach(function (c, i) {
          var p = cs[i - 1], nx = cs[i + 1];
          var jp = p && p.joinNext && c.joinPrev, jn = nx && c.joinNext && nx.joinPrev;
          add((jp ? ZWJ : '') + c.t + (jn ? ZWJ : ''));
        });
      } else if (!arabic && !rtl) {
        Array.from(w).forEach(add);
      } else {
        add(w);                       // كلمة بلغة أخرى تقفز كاملة حتى لا ينقلب ترتيب حروفها
      }
    });
    fitFares();
  }
  function fitFares() {
    var el = $('s4-txtfares');
    el.style.fontSize = '';
    var size = parseFloat(getComputedStyle(el).fontSize), guard = 0;
    while (el.scrollWidth > el.clientWidth + 1 && guard++ < 30) { size *= 0.92; el.style.fontSize = size + 'px'; }
  }
  ENTER.s4 = function () {
    // مربع النص txtfares يعرض اسم الفارس (المتغير txtnamefars)
    bounceText($('s4-txtfares'), S.user ? S.user.fars : '');
  };

  // ================================================================ شريحة 5: زيادة المعرفة
  function setQuestion(text) {
    var el = $('s5-sss1');
    el.innerHTML = '';
    var d = document.createElement('div'); d.className = 'qin'; d.textContent = text;
    el.appendChild(d);
    fitText(el, 0.6);
    el.scrollTop = 0;
  }
  function setAnswers(list, locked) {
    for (var k = 0; k < 3; k++) {
      var el = $('s5-j' + (k + 1));
      el.textContent = list[k] || '';
      el.classList.toggle('locked', !!locked);
      fitText(el, 0.5);
    }
  }
  function nextQuestion() {
    var q = S.quiz, qs = S.data.questions || [];
    if (!qs.length) {
      q.cur = null;
      setQuestion(S.loaded ? 'لا توجد أسئلة بعد، انتظر حتى يضيفها المعلم.'
        : (S.bootError ? 'تعذّر تحميل الأسئلة، تحقق من الاتصال بالإنترنت ثم ادخل من جديد.' : 'جارٍ تحميل الأسئلة…'));
      setAnswers(['', '', ''], true);
      return;
    }
    if (!q.deck.length || q.deck.some(function (i) { return i >= qs.length; })) {
      q.deck = shuffle(qs.map(function (_, i) { return i; }));
      if (q.deck.length > 1 && q.deck[q.deck.length - 1] === q.last) {   // لا يتكرر السؤال نفسه مرتين متتاليتين
        var t = q.deck[0]; q.deck[0] = q.deck[q.deck.length - 1]; q.deck[q.deck.length - 1] = t;
      }
    }
    var idx = q.deck.pop();
    q.last = idx;
    var item = qs[idx];
    var order = shuffle([0, 1, 2]);                         // خلط الأجوبة الثلاثة عشوائيًا
    q.cur = { item: item, order: order };
    setQuestion(item.q);
    setAnswers(order.map(function (o) { return item.a[o]; }), q.lock);
  }
  function showVerdict(ok) {
    var q = S.quiz;
    $('s5-picsah').classList.remove('show'); $('s5-pickata').classList.remove('show');
    void $('s5-picsah').offsetWidth;
    $(ok ? 's5-picsah' : 's5-pickata').classList.add('show');
    q.lock = true;
    setAnswers([$('s5-j1').textContent, $('s5-j2').textContent, $('s5-j3').textContent], true);
    clearTimeout(q.timer);
    q.timer = setTimeout(hideVerdict, 500);                 // تختفي الصورة ويظهر السؤال التالي بعد نصف ثانية
  }
  function hideVerdict() {
    var q = S.quiz;
    clearTimeout(q.timer);
    $('s5-picsah').classList.remove('show'); $('s5-pickata').classList.remove('show');
    q.lock = false;
    if (q.cur) for (var k = 1; k <= 3; k++) $('s5-j' + k).classList.remove('locked');
  }
  function onAnswer(el) {
    var q = S.quiz;
    if (!q.cur || q.lock) return;
    var k = +el.getAttribute('data-i');
    var chosen = q.cur.order[k];
    var ok = chosen === q.cur.item.c;                        // مقارنة بالجواب الصحيح (rahgit)
    q.dirty = true;
    if (ok) { play('sotsah'); q.newrasi += 1; }
    else { play('sotkat'); q.newrasi -= 1; }
    $('s5-newras').textContent = q.newrasi;
    showVerdict(ok);
    nextQuestion();                                          // السؤال الجديد جاهز تحت الصورة
  }
  ENTER.s5 = function () {
    var q = S.quiz;
    q.newrasir = num(S.rasid && S.rasid.asilah);             // newrasir: الرصيد المحفوظ في asilah
    q.newrasi = 0;                                           // newrasi: يبدأ من صفر في كل مرة تُفتح الصفحة
    q.dirty = false;
    $('s5-rasidhali').textContent = q.newrasir;
    $('s5-newras').textContent = q.newrasi;
    hideVerdict();
    nextQuestion();
    refreshRasid().then(function () {
      if (S.current === 's5' && S.rasid) {
        q.newrasir = num(S.rasid.asilah);
        $('s5-rasidhali').textContent = q.newrasir;
      }
    });
  };
  function saveQuizIfBetter() {
    var q = S.quiz;
    if (!S.user || !q.dirty) return;
    if (q.newrasi > q.newrasir) {                            // يُحفظ فقط إن زاد الرصيد
      saveScore(q.newrasi);
      q.newrasir = q.newrasi;
      $('s5-rasidhali').textContent = q.newrasir;
    }
  }
  function quizBack() {
    hideVerdict();
    saveQuizIfBetter();
    S.quiz.dirty = false;
    go('s4');
  }
  // حفظ الرصيد في صفحة rasid (عمود asilah) — مع إعادة المحاولة لاحقًا إن انقطع الاتصال
  function saveScore(score) {
    if (!S.user) return;
    S.rasid = S.rasid || { asilah: 0, takiimat: 0, takim2: 0, majmo: 0 };
    S.rasid.asilah = score;
    S.rasid.majmo = num(S.rasid.asilah) + num(S.rasid.takiimat) + num(S.rasid.takim2);
    store('forsan.pendingScore', { name: S.user.name, score: score });
    flushScore();
  }
  function flushScore() {
    var p = load('forsan.pendingScore');
    if (!p || !p.name) return;
    api('saveScore', { name: p.name, score: p.score }).then(function (r) {
      if (r.ok) {
        var still = load('forsan.pendingScore');
        if (still && still.name === p.name && still.score === p.score) store('forsan.pendingScore', null);
        if (S.user && S.user.name === r.name && r.rasid) S.rasid = r.rasid;
        if (r.leaders) { S.data.leaders = r.leaders; store('forsan.data', S.data); }
      }
    }).catch(function () { /* تبقى محفوظة وتُرسل في المرة القادمة */ });
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden && S.current === 's5') saveQuizIfBetter();
  });

  // ================================================================ شريحة 6: أفضل الفرسان
  function renderLeaders() {
    var L = S.data.leaders || [];
    for (var i = 0; i < 3; i++) {
      var el = $('s6-name' + (i + 1));
      el.textContent = L[i] ? L[i].f + ' (' + L[i].s + ')' : '';
      fitText(el, 0.5);
    }
  }
  ENTER.s6 = function () { renderLeaders(); refreshRasid().then(function () { if (S.current === 's6') renderLeaders(); }); };

  // ================================================================ شريحة 7: إضافة فائدة
  function doAddBenefit() {
    var title = $('s7-txtinoan').value.trim();
    var text = $('s7-txtfaidh').value.trim();
    if (!title || !text) return msg('اكتب عنوان الفائدة ونصّها قبل الإضافة');
    api('addBenefit', { name: S.user.name, title: title, text: text }, { busy: true }).then(function (r) {
      if (!r.ok) return msg(errText({ code: 'server', msg: r.msg }));
      if (r.item) {
        if (!r.item.f && S.user) r.item.f = S.user.fars;
        S.data.benefits.unshift(r.item); store('forsan.data', S.data);
      }
      $('s7-txtinoan').value = ''; $('s7-txtfaidh').value = '';
      msg('أُضيفت فائدتك بنجاح، جزاك الله خيرًا');
    }, function (e) { msg(errText(e)); });
  }

  // ================================================================ شريحة 9: فوائد الفرسان
  function makeList(box, items, label, selected, onPick, emptyText) {
    box.innerHTML = '';
    if (!items.length) {
      var em = document.createElement('div'); em.className = 'empty'; em.textContent = emptyText;
      box.appendChild(em); return;
    }
    items.forEach(function (it, i) {
      var d = document.createElement('div');
      d.className = 'item' + (selected === it ? ' sel' : '');
      d.setAttribute('role', 'option');
      d.textContent = label(it);
      d.addEventListener('click', function () {
        var all = box.querySelectorAll('.item');
        for (var k = 0; k < all.length; k++) all[k].classList.remove('sel');
        d.classList.add('sel');
        onPick(it);
      });
      box.appendChild(d);
    });
  }
  function showBenefit(b) {
    S.selBenefit = b;
    $('s9-TextBox1').textContent = b ? b.m : '';             // المشاركة (moshrkkh)
    $('s9-TextBox1').scrollTop = 0;
    $('s9-name1').textContent = b ? (b.f || b.n) : '';       // اسم الفارس (txtnamefars) لصاحب المشاركة
    $('s9-takiiim').textContent = b ? (b.k === '' || b.k == null ? 'لم تُقيَّم بعد' : b.k) : '';   // التقييم (takiim)
  }
  function renderBenefits() {
    var list = S.data.benefits || [];
    var sel = S.selBenefit && list.filter(function (b) { return b.id === S.selBenefit.id; })[0];
    makeList($('s9-Listmosharka'), list, function (b) { return b.t; }, sel, showBenefit,
      S.loaded ? 'لا توجد مشاركات بعد' : 'جارٍ التحميل…');
    showBenefit(sel || null);
  }
  ENTER.s9 = function () {
    S.selBenefit = null;
    renderBenefits();
    api('benefits').then(function (r) {
      if (r.ok && r.benefits) { S.data.benefits = r.benefits; store('forsan.data', S.data); if (S.current === 's9') renderBenefits(); }
    }).catch(function () { });
  };

  // ================================================================ شريحة 11: رصيدي
  function renderRasid() {
    var r = S.rasid || {};
    $('s11-r1').textContent = num(r.asilah);                                  // asilah
    $('s11-r2').textContent = num(r.takiimat) + num(r.takim2);                 // takiimat + takim2
    $('s11-r3').textContent = num(r.asilah) + num(r.takiimat) + num(r.takim2); // majmo
  }
  ENTER.s11 = function () { renderRasid(); refreshRasid().then(function () { if (S.current === 's11') renderRasid(); }); };

  // ================================================================ شريحة 12 و 13: دروس المعلم
  function renderLessons() {
    var list = S.data.lessons || [];
    var sel = S.selLesson && list.filter(function (l) { return l.t === S.selLesson.t; })[0];
    S.selLesson = sel || null;
    makeList($('s12-Listdars'), list, function (l) { return l.t; }, sel, function (l) { S.selLesson = l; },
      S.loaded ? 'لا توجد دروس بعد' : 'جارٍ التحميل…');
  }
  ENTER.s12 = function () {
    S.selLesson = null;
    renderLessons();
    api('lessons').then(function (r) {
      if (r.ok && r.lessons) { S.data.lessons = r.lessons; store('forsan.data', S.data); if (S.current === 's12') renderLessons(); }
    }).catch(function () { });
  };
  function openLesson() {
    if (!S.selLesson) return msg('اختر عنوانا للاطلاع عليه');
    S.ismdars = S.selLesson.t;                               // المتغير ismdars
    go('s13');
  }
  ENTER.s13 = function () {
    var l = (S.data.lessons || []).filter(function (x) { return x.t === S.ismdars; })[0];
    $('s13-txtdars').textContent = l ? l.x : '';
    $('s13-txtdars').scrollTop = 0;
    $('s13-txtijabh').value = S.drafts[S.ismdars] || '';
  };
  $('s13-txtijabh').addEventListener('input', function () { S.drafts[S.ismdars] = this.value; });

  function doAnswer() {
    var text = $('s13-txtijabh').value.trim();
    if (!text) return msg('اكتب إجابتك أولًا ثم اضغط «أجب»');
    api('answer', { name: S.user.name, title: S.ismdars, text: text }, { busy: true }).then(function (r) {
      if (!r.ok) {
        if (r.code === 'evaluated') return msg('لقد قيَّم المعلم إجابتك');
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      msg('أُرسلت إجابتك إلى المعلم بنجاح');
    }, function (e) { msg(errText(e)); });
  }

  // ---------------------------------------------------------------- ربط الأزرار
  function to(id) { return function () { go(id); }; }
  var ACTIONS = {
    s1: { dokol: to('s2'), enshahesab: to('s3'), koroj: exitApp },
    s2: { dokol: doLogin, aodah: to('s1') },
    s3: { cmdnew: doRegister, aodah: to('s1') },
    s4: {
      addfaidh: to('s7'), afdal: to('s6'), faoaid: to('s9'), ziadh: to('s5'),
      doros: to('s12'), rasidy: to('s11'), aodah: logout, koroj: function () { saveQuizIfBetter(); exitApp(); }
    },
    s5: { answer: onAnswer, aodah: quizBack },
    s6: { aodah: to('s4') },
    s7: { edafh: doAddBenefit, aodah: to('s4') },
    s9: { aodah: to('s4') },
    s11: { aodah: to('s4') },
    s12: { istirad: openLesson, aodah: to('s4') },
    s13: { ajb: doAnswer, aodah: to('s4') }
  };

  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!t || S.busy || msgOpen) return;
    var scr = t.closest('.screen');
    if (!scr || scr.id !== S.current) return;
    var act = t.getAttribute('data-act');
    var now = Date.now();
    if (act !== 'answer') {                                   // منع الضغط المزدوج على الأزرار
      if (now - S.lastTap < 350) return;
      S.lastTap = now;
    }
    var fn = ACTIONS[scr.id] && ACTIONS[scr.id][act];
    if (fn) fn(t);
  });

  // زر الرجوع في الجوال يعمل عمل زر «عودة» في كل شاشة
  window.androidBack = function () {
    if (msgOpen) { closeMsg(); return; }
    if (S.busy) return;
    if (S.current === 's1') { exitApp(); return; }
    var fn = ACTIONS[S.current] && ACTIONS[S.current].aodah;
    if (fn) fn();
  };

  // ---------------------------------------------------------------- البدء
  function start() {
    measure();
    go('s1');
    boot();
    setTimeout(measure, 300);
    setTimeout(measure, 1200);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { refitCurrent(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();

  // للاختبار فقط
  window.__forsan = { S: S, go: go };
})();
