/* ============================================================
   فرسان المعرفة — منطق التطبيق
   أسماء الشاشات s1 … s13 تطابق أرقام شرائح البوربوينت،
   وأسماء العناصر تطابق أسماءها في الشرائح (dokol, txtname, sss1 …).
   ============================================================ */
(function () {
  'use strict';

  var RATIO = 6911975 / 3887788;             // نسبة الشريحة (الطول ÷ العرض)
  var API = String(window.FORSAN_API || '').trim();
  var ZWJ = '‍';

  function $(id) { return document.getElementById(id); }

  // ---------------------------------------------------------------- الحالة
  var S = {
    current: null,
    user: null,          // { name: nameacount1, fars: txtnamefars }
    rasid: null,         // { asilah, takiimat, takim2, tahadi, majmo }
    data: { questions: [], lessons: [], benefits: [], leaders: [] },
    loaded: false,       // وصلت البيانات (من الخادم أو من النسخة المحفوظة)
    bootError: null,
    busy: false,
    lastTap: 0,
    quiz: { deck: [], last: -1, cur: null, newrasi: 0, newrasir: 0, dirty: false, lock: false, timer: 0 },
    selBenefit: null,
    selLesson: null,
    ismdars: null,
    drafts: {}
  };

  // ---------------------------------------------------------------- تخزين محلي آمن
  function load(key) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch (e) { return null; }
  }
  function store(key, val) {
    try { if (val === null) localStorage.removeItem(key); else localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* لا شيء */ }
  }

  // ---------------------------------------------------------------- أدوات
  function num(v) {
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var s = String(v == null ? '' : v).replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); })
      .replace(/[^\d.\-]/g, '');
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  // تصغير الخط حتى يتسع النص لمربعه
  function fitText(el, minRatio) {
    el.style.fontSize = '';
    var base = parseFloat(getComputedStyle(el).fontSize) || 16;
    var size = base, min = base * (minRatio || 0.55);
    var guard = 0;
    while ((el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) && size > min && guard++ < 40) {
      size = size * 0.93;
      el.style.fontSize = size + 'px';
    }
  }

  // ---------------------------------------------------------------- مقاس الشاشة ولوحة المفاتيح
  var stable = { w: 0, h: 0 }, kbJava = 0, kbResize = 0, shiftNow = 0;

  function typingEl() {
    var a = document.activeElement;
    return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') ? a : null;
  }

  function measure() {
    var w = window.innerWidth, h = window.innerHeight;
    if (!w || !h) return;
    // إذا صغر ارتفاع النافذة بسبب لوحة المفاتيح فلا نصغّر التصميم، بل نرفع الخانة فقط
    if (typingEl() && stable.w && w === stable.w && h < stable.h) {
      kbResize = stable.h - h; updateShift(); return;
    }
    kbResize = 0;
    stable = { w: w, h: h };
    var app = $('app');
    app.style.width = w + 'px'; app.style.height = h + 'px';
    var sw = w, sh = w * RATIO;
    if (sh > h) { sh = h; sw = h / RATIO; }
    var st = $('stage');
    st.style.width = sw + 'px'; st.style.height = sh + 'px';
    st.style.left = ((w - sw) / 2) + 'px'; st.style.top = ((h - sh) / 2) + 'px';
    document.documentElement.style.setProperty('--u', (sw / 100) + 'px');
    updateShift();
    refitCurrent();
  }

  function updateShift() {
    var a = typingEl(), app = $('app');
    var kb = Math.max(kbJava, kbResize);
    if (!a || kb <= 0) { shiftNow = 0; app.style.transform = ''; return; }
    var stTop = parseFloat($('stage').style.top) || 0;
    var top = stTop + a.offsetTop, bottom = top + a.offsetHeight;
    var visible = stable.h - kb, margin = stable.h * 0.03;
    var shift = 0;
    if (bottom + margin > visible) shift = bottom + margin - visible;
    shift = Math.max(0, Math.min(shift, top - margin));   // لا نخفي أعلى الخانة
    shiftNow = shift;
    app.style.transform = shift ? 'translateY(' + (-shift) + 'px)' : '';
  }

  // يستدعيها غلاف أندرويد كلما ظهرت لوحة المفاتيح أو اختفت (بالبكسل)
  window.__forsanKeyboard = function (px) { kbJava = Math.max(0, +px || 0); updateShift(); };

  document.addEventListener('focusin', function () { setTimeout(updateShift, 60); setTimeout(updateShift, 350); });
  document.addEventListener('focusout', function () { setTimeout(updateShift, 80); });
  window.addEventListener('resize', measure);

  // ---------------------------------------------------------------- التنقل بين الشاشات
  var ENTER = {};

  function go(id) {
    var next = $(id);
    if (!next || S.current === id) return;
    var a = typingEl(); if (a) a.blur();
    if (S.current) {
      var prev = $(S.current);
      prev.classList.remove('visible', 'shown');
    }
    S.current = id;
    var top = next.getAttribute('data-edge-top'), bottom = next.getAttribute('data-edge-bottom');
    document.body.style.background = 'linear-gradient(180deg,' + top + ' 50%,' + bottom + ' 50%)';
    next.classList.add('shown');
    void next.offsetWidth;            // لبدء حركة الظهور
    next.classList.add('visible');
    if (ENTER[id]) ENTER[id]();
  }

  function refitCurrent() {
    var id = S.current;
    if (!id) return;
    var els = $(id).querySelectorAll('.txt');
    for (var i = 0; i < els.length; i++) {
      if (els[i].id === 's4-txtfares') fitFares();
      else if (els[i].classList.contains('question')) fitText(els[i], 0.6);
      else if (els[i].textContent) fitText(els[i], 0.5);
    }
  }

  // ---------------------------------------------------------------- الرسائل ومؤشر الانتظار
  var msgQueue = [], msgOpen = false;
  function msg(text) {
    return new Promise(function (resolve) {
      msgQueue.push({ text: text, resolve: resolve });
      if (!msgOpen) nextMsg();
    });
  }
  function nextMsg() {
    var m = msgQueue.shift();
    if (!m) { msgOpen = false; $('msg').hidden = true; return; }
    msgOpen = true;
    $('msg-text').textContent = m.text;
    $('msg').hidden = false;
    $('msg').__resolve = m.resolve;
  }
  function closeMsg() {
    var r = $('msg').__resolve; $('msg').__resolve = null;
    if (r) r();
    nextMsg();
  }
  $('msg-ok').addEventListener('click', function (e) { e.stopPropagation(); closeMsg(); });

  var busyTimer = 0;
  function setBusy(on) {
    S.busy = on;
    clearTimeout(busyTimer);
    if (on) busyTimer = setTimeout(function () { $('busy').hidden = false; }, 250);  // لا يظهر للردود السريعة
    else $('busy').hidden = true;
  }

  // ---------------------------------------------------------------- الاتصال بقاعدة البيانات (Google Sheets)
  // فرق ساعة الجوال عن ساعة الخادم، ليظهر سؤال التحدي على الجوالين في اللحظة نفسها
  var CLK = { off: 0, d: 0, when: 0 };
  function clockSample(serverNow, t0, t1) {
    var d = t1 - t0, est = serverNow - (t0 + t1) / 2;
    // نعتمد أسرع رد (أقل خطأ)، ونجدد التقدير كل دقيقة
    if (!CLK.when || d <= CLK.d || t1 - CLK.when > 60000) { CLK.off = est; CLK.d = d; CLK.when = t1; }
  }
  function serverToLocal(t) { return t - CLK.off; }

  function api(action, payload, opts) {
    opts = opts || {};
    if (!/^https:\/\//.test(API)) return Promise.reject({ code: 'noapi' });
    var t0 = Date.now();
    if (opts.busy) setBusy(true);
    var body = { action: action };
    for (var k in (payload || {})) body[k] = payload[k];
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 30000);
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(body),
      redirect: 'follow',
      cache: 'no-store',
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (res) { return res.text(); })
      .then(function (txt) {
        var r;
        try { r = JSON.parse(txt); } catch (e) { throw { code: 'badjson' }; }
        if (r && typeof r.now === 'number') clockSample(r.now, t0, Date.now());
        return r;
      })
      .catch(function (err) { throw (err && err.code) ? err : { code: 'net' }; })
      .then(function (r) { clearTimeout(timer); if (opts.busy) setBusy(false); return r; },
        function (e) { clearTimeout(timer); if (opts.busy) setBusy(false); throw e; });
  }

  function errText(e) {
    if (e && e.code === 'noapi') return 'لم يُضبط رابط قاعدة البيانات داخل التطبيق بعد.';
    if (e && e.code === 'badjson') return 'وصل رد غير مفهوم من قاعدة البيانات.\nتأكد أن السكربت منشور بصلاحية «أي شخص».';
    if (e && e.code === 'server') return 'حدث خطأ في قاعدة البيانات:\n' + (e.msg || '');
    return 'تعذّر الاتصال بقاعدة البيانات.\nتأكد من اتصالك بالإنترنت ثم أعد المحاولة.\nوإن تكرر ذلك مع وجود الإنترنت، فتأكد أن السكربت منشور بصلاحية «أي شخص».';
  }

  // تحميل الأسئلة والدروس والفوائد مسبقًا حتى تُعرض فورًا دون انتظار
  function applyData(r) {
    if (r.questions) S.data.questions = r.questions;
    if (r.lessons) S.data.lessons = r.lessons;
    if (r.benefits) S.data.benefits = r.benefits;
    if (r.leaders) S.data.leaders = r.leaders;
    S.loaded = true;
    store('forsan.data', S.data);
  }

  function boot() {
    var cached = load('forsan.data');
    if (cached && cached.questions) { S.data = cached; S.loaded = true; }
    return api('boot').then(function (r) {
      if (!r.ok) throw { code: 'server', msg: r.msg };
      S.bootError = null;
      applyData(r);
      dataChanged();
    }).catch(function (e) {
      S.bootError = e;
      dataChanged();
    }).then(flushScore);
  }

  function dataChanged() {
    if (S.current === 's5' && !S.quiz.cur) nextQuestion();
    if (S.current === 's6') renderLeaders();
    if (S.current === 's9') renderBenefits();
    if (S.current === 's12') renderLessons();
  }

  function refreshRasid() {
    if (!S.user) return Promise.resolve();
    return api('rasid', { name: S.user.name }).then(function (r) {
      if (r.ok) {
        if (r.rasid) S.rasid = r.rasid;
        if (r.leaders) { S.data.leaders = r.leaders; store('forsan.data', S.data); }
      }
    }).catch(function () { /* نكتفي بالبيانات الموجودة */ });
  }

  // ---------------------------------------------------------------- الأصوات
  var SND = { ctx: null, buf: {} };
  function initAudio() {
    if (SND.ctx) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { SND.ctx = new AC(); } catch (e) { return; }
    ['sotsah', 'sotkat'].forEach(function (n) {
      fetch('snd/' + n + '.wav').then(function (r) { return r.arrayBuffer(); }).then(function (b) {
        SND.ctx.decodeAudioData(b, function (buf) { SND.buf[n] = buf; }, function () { });
      }).catch(function () { });
    });
  }
  function play(n) {
    try {
      if (!SND.ctx) initAudio();
      if (SND.ctx && SND.ctx.state === 'suspended') SND.ctx.resume();
      var b = SND.buf[n];
      if (!SND.ctx || !b) { var a = new Audio('snd/' + n + '.wav'); a.play().catch(function () { }); return; }
      var s = SND.ctx.createBufferSource(); s.buffer = b; s.connect(SND.ctx.destination); s.start(0);
    } catch (e) { /* لا شيء */ }
  }
  document.addEventListener('pointerdown', initAudio, { once: true });
  document.addEventListener('touchstart', initAudio, { once: true });

  // ---------------------------------------------------------------- الخروج من التطبيق
  function exitApp() {
    if (window.Android && Android.exitApp) Android.exitApp();
    else window.close();
  }

  // ---------------------------------------------------------------- الجلسة
  function startSession(r) {
    S.user = { name: r.name, fars: r.fars };               // nameacount1 و txtnamefars
    S.rasid = r.rasid || { asilah: 0, takiimat: 0, takim2: 0, tahadi: 0, majmo: 0 };
    if (r.leaders) S.data.leaders = r.leaders;
    store('forsan.lastName', r.name);
    flushScore();
    LB.seen = {}; LB.list = null; LB.winners = null;
    lobbySoon(300);                                         // يظهر اسمه في قائمة الفرسان النشطين
  }
  function logout() {
    saveQuizIfBetter();
    if (S.user) api('bye', { name: S.user.name }).catch(function () { });
    clearTimeout(LB.timer); LB.out = null; LB.inv = null;
    if (ASK.open) closeAsk();
    S.user = null; S.rasid = null;
    $('s2-txtpas').value = '';
    go('s2');
  }

  // ================================================================ شريحة 1 و 2: الدخول
  function validName(n) {
    return Array.from(n).length <= 10 && !/\s/.test(n) && !/^[=+\-–—−]/.test(n);
  }

  function doLogin() {
    var name = $('s2-txtname').value.trim();
    var pas = $('s2-txtpas').value;
    if (!name) return msg('إن كان عندك اسم حساب فاكتبه، وإلا فأنشئ حسابًا جديدًا من الصفحة الرئيسية');
    api('login', { name: name, pas: pas }, { busy: true }).then(function (r) {
      if (!r.ok) {
        if (r.code === 'nouser') return msg('لا يوجد حساب مسجل بهذا الاسم');
        if (r.code === 'nopass') return msg('يجب إدخال كلمة مرور');
        if (r.code === 'badpass') return msg('كلمة المرور غير صحيحة');
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      startSession(r);
      $('s2-txtpas').value = '';
      go('s4');
    }, function (e) { msg(errText(e)); });
  }

  ENTER.s2 = function () {
    var last = load('forsan.lastName');
    if (last && !$('s2-txtname').value) $('s2-txtname').value = last;
  };

  // ================================================================ شريحة 3: إنشاء حساب
  function doRegister() {
    var name = $('s3-txtnameac').value.trim();
    var fars = $('s3-txtnamefars').value.trim();
    var pas = $('s3-txtpas').value;
    if (!name || !fars || !pas) return msg('تأكد من ملء جميع الخانات قبل الاستمرار');
    if (!validName(name)) return msg('لا يمكن التسمية بهذا الاسم، اختر اسمًا مناسبًا');
    api('register', { name: name, fars: fars, pas: pas }, { busy: true }).then(function (r) {
      if (!r.ok) {
        if (r.code === 'exists') return msg('الاسم موجود، يمكنك تسجيل الدخول إذا كنت صاحب الحساب، أو اختر اسمًا آخر');
        if (r.code === 'badname') return msg('لا يمكن التسمية بهذا الاسم، اختر اسمًا مناسبًا');
        if (r.code === 'empty') return msg('تأكد من ملء جميع الخانات قبل الاستمرار');
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      startSession(r);
      $('s3-txtnameac').value = ''; $('s3-txtnamefars').value = ''; $('s3-txtpas').value = '';
      $('s2-txtname').value = r.name;
      go('s4');
      msg('أُنشِئ حساب الفارس بنجاح');
    }, function (e) { msg(errText(e)); });
  }

  // ================================================================ شريحة 4: قائمة الفارس
  // تقسيم النص العربي إلى حروف مع المحافظة على اتصالها، حتى يقفز كل حرف وحده
  var RIGHT_ONLY = 'اأإآٱدذرزوؤةژڈڑ';
  function joinType(ch) {
    if (!ch) return 'U';
    if (ch === 'ء') return 'U';
    if (ch === 'ـ') return 'C';
    if (RIGHT_ONLY.indexOf(ch) >= 0) return 'R';
    var c = ch.charCodeAt(0);
    if ((c >= 0x0620 && c <= 0x064A) || (c >= 0x066E && c <= 0x06D3) || c === 0x06D5 || (c >= 0x06EE && c <= 0x06FF)) return 'D';
    return 'U';
  }
  function isMark(ch) {
    var c = ch.charCodeAt(0);
    return (c >= 0x064B && c <= 0x065F) || c === 0x0670 || (c >= 0x06D6 && c <= 0x06DC) ||
      (c >= 0x06DF && c <= 0x06E4) || c === 0x06E7 || c === 0x06E8 || (c >= 0x06EA && c <= 0x06ED);
  }
  function clusters(text) {
    var out = [], chars = Array.from(text);
    for (var i = 0; i < chars.length; i++) {
      var ch = chars[i];
      if (isMark(ch) && out.length) { out[out.length - 1].t += ch; continue; }
      out.push({ t: ch, b: ch, last: ch });
    }
    // لام ألف تبقى مجتمعة
    var merged = [];
    for (var j = 0; j < out.length; j++) {
      var cur = out[j], nx = out[j + 1];
      if (cur.b === 'ل' && nx && 'اأإآٱ'.indexOf(nx.b) >= 0) {
        merged.push({ t: cur.t + nx.t, b: 'ل', last: nx.b }); j++;
      } else merged.push(cur);
    }
    return merged.map(function (c) {
      var first = joinType(c.b), last = joinType(c.last);
      return { t: c.t, joinPrev: first === 'D' || first === 'R' || first === 'C', joinNext: last === 'D' || last === 'C' };
    });
  }
  function bounceText(el, text) {
    el.innerHTML = '';
    var LATIN = /[A-Za-zÀ-ɏ]/, ARABIC = /[؀-ۿ]/;
    // اتجاه السطر بحسب أول حرف: عربي ← من اليمين، لاتيني ← من اليسار
    var firstStrong = (text.match(/[A-Za-zÀ-ɏ؀-ۿ]/) || [''])[0];
    var rtl = !LATIN.test(firstStrong);
    el.style.direction = rtl ? 'rtl' : 'ltr';
    var n = 0;
    function add(t) {
      var s = document.createElement('span');
      s.className = 'ch';
      s.textContent = t;
      s.style.animationDelay = (n++ * 0.11) + 's';
      el.appendChild(s);
    }
    String(text || '').split(/(\s+)/).forEach(function (w) {
      if (!w) return;
      if (/^\s+$/.test(w)) { add(' '); return; }
      var arabic = ARABIC.test(w);
      if (arabic && rtl) {
        var cs = clusters(w);
        cs.forEach(function (c, i) {
          var p = cs[i - 1], nx = cs[i + 1];
          var jp = p && p.joinNext && c.joinPrev, jn = nx && c.joinNext && nx.joinPrev;
          add((jp ? ZWJ : '') + c.t + (jn ? ZWJ : ''));
        });
      } else if (!arabic && !rtl) {
        Array.from(w).forEach(add);
      } else {
        add(w);                       // كلمة بلغة أخرى تقفز كاملة حتى لا ينقلب ترتيب حروفها
      }
    });
    fitFares();
  }
  function fitFares() {
    var el = $('s4-txtfares');
    el.style.fontSize = '';
    var size = parseFloat(getComputedStyle(el).fontSize), guard = 0;
    while (el.scrollWidth > el.clientWidth + 1 && guard++ < 30) { size *= 0.92; el.style.fontSize = size + 'px'; }
  }
  ENTER.s4 = function () {
    // مربع النص txtfares يعرض اسم الفارس (المتغير txtnamefars)
    bounceText($('s4-txtfares'), S.user ? S.user.fars : '');
  };

  // ================================================================ شريحة 5: زيادة المعرفة
  function setQuestion(text) {
    var el = $('s5-sss1');
    el.innerHTML = '';
    var d = document.createElement('div'); d.className = 'qin'; d.textContent = text;
    el.appendChild(d);
    fitText(el, 0.6);
    el.scrollTop = 0;
  }
  function setAnswers(list, locked) {
    for (var k = 0; k < 3; k++) {
      var el = $('s5-j' + (k + 1));
      el.textContent = list[k] || '';
      el.classList.toggle('locked', !!locked);
      fitText(el, 0.5);
    }
  }
  function nextQuestion() {
    var q = S.quiz, qs = S.data.questions || [];
    if (!qs.length) {
      q.cur = null;
      setQuestion(S.loaded ? 'لا توجد أسئلة بعد، انتظر حتى يضيفها المعلم.'
        : (S.bootError ? 'تعذّر تحميل الأسئلة، تحقق من الاتصال بالإنترنت ثم ادخل من جديد.' : 'جارٍ تحميل الأسئلة…'));
      setAnswers(['', '', ''], true);
      return;
    }
    if (!q.deck.length || q.deck.some(function (i) { return i >= qs.length; })) {
      q.deck = shuffle(qs.map(function (_, i) { return i; }));
      if (q.deck.length > 1 && q.deck[q.deck.length - 1] === q.last) {   // لا يتكرر السؤال نفسه مرتين متتاليتين
        var t = q.deck[0]; q.deck[0] = q.deck[q.deck.length - 1]; q.deck[q.deck.length - 1] = t;
      }
    }
    var idx = q.deck.pop();
    q.last = idx;
    var item = qs[idx];
    var order = shuffle([0, 1, 2]);                         // خلط الأجوبة الثلاثة عشوائيًا
    q.cur = { item: item, order: order };
    setQuestion(item.q);
    setAnswers(order.map(function (o) { return item.a[o]; }), q.lock);
  }
  function showVerdict(ok) {
    var q = S.quiz;
    $('s5-picsah').classList.remove('show'); $('s5-pickata').classList.remove('show');
    void $('s5-picsah').offsetWidth;
    $(ok ? 's5-picsah' : 's5-pickata').classList.add('show');
    q.lock = true;
    setAnswers([$('s5-j1').textContent, $('s5-j2').textContent, $('s5-j3').textContent], true);
    clearTimeout(q.timer);
    q.timer = setTimeout(hideVerdict, 500);                 // تختفي الصورة ويظهر السؤال التالي بعد نصف ثانية
  }
  function hideVerdict() {
    var q = S.quiz;
    clearTimeout(q.timer);
    $('s5-picsah').classList.remove('show'); $('s5-pickata').classList.remove('show');
    q.lock = false;
    if (q.cur) for (var k = 1; k <= 3; k++) $('s5-j' + k).classList.remove('locked');
  }
  function onAnswer(el) {
    var q = S.quiz;
    if (!q.cur || q.lock) return;
    var k = +el.getAttribute('data-i');
    var chosen = q.cur.order[k];
    var ok = chosen === q.cur.item.c;                        // مقارنة بالجواب الصحيح (rahgit)
    q.dirty = true;
    if (ok) { play('sotsah'); q.newrasi += 1; }
    else { play('sotkat'); q.newrasi -= 1; }
    $('s5-newras').textContent = q.newrasi;
    showVerdict(ok);
    nextQuestion();                                          // السؤال الجديد جاهز تحت الصورة
  }
  ENTER.s5 = function () {
    var q = S.quiz;
    q.newrasir = num(S.rasid && S.rasid.asilah);             // newrasir: الرصيد المحفوظ في asilah
    q.newrasi = 0;                                           // newrasi: يبدأ من صفر في كل مرة تُفتح الصفحة
    q.dirty = false;
    $('s5-rasidhali').textContent = q.newrasir;
    $('s5-newras').textContent = q.newrasi;
    hideVerdict();
    nextQuestion();
    refreshRasid().then(function () {
      if (S.current === 's5' && S.rasid) {
        q.newrasir = num(S.rasid.asilah);
        $('s5-rasidhali').textContent = q.newrasir;
      }
    });
  };
  function saveQuizIfBetter() {
    var q = S.quiz;
    if (!S.user || !q.dirty) return;
    if (q.newrasi > q.newrasir) {                            // يُحفظ فقط إن زاد الرصيد
      saveScore(q.newrasi);
      q.newrasir = q.newrasi;
      $('s5-rasidhali').textContent = q.newrasir;
    }
  }
  function quizBack() {
    hideVerdict();
    saveQuizIfBetter();
    S.quiz.dirty = false;
    go('s4');
  }
  // حفظ الرصيد في صفحة rasid (عمود asilah) — مع إعادة المحاولة لاحقًا إن انقطع الاتصال
  function saveScore(score) {
    if (!S.user) return;
    S.rasid = S.rasid || { asilah: 0, takiimat: 0, takim2: 0, tahadi: 0, majmo: 0 };
    S.rasid.asilah = score;
    S.rasid.majmo = num(S.rasid.asilah) + num(S.rasid.takiimat) + num(S.rasid.takim2) + num(S.rasid.tahadi);
    store('forsan.pendingScore', { name: S.user.name, score: score });
    flushScore();
  }
  function flushScore() {
    var p = load('forsan.pendingScore');
    if (!p || !p.name) return;
    api('saveScore', { name: p.name, score: p.score }).then(function (r) {
      if (r.ok) {
        var still = load('forsan.pendingScore');
        if (still && still.name === p.name && still.score === p.score) store('forsan.pendingScore', null);
        if (S.user && S.user.name === r.name && r.rasid) S.rasid = r.rasid;
        if (r.leaders) { S.data.leaders = r.leaders; store('forsan.data', S.data); }
      }
    }).catch(function () { /* تبقى محفوظة وتُرسل في المرة القادمة */ });
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden && S.current === 's5') saveQuizIfBetter();
  });

  // ================================================================ شريحة 6: أفضل الفرسان
  function renderLeaders() {
    var L = S.data.leaders || [];
    for (var i = 0; i < 3; i++) {
      var el = $('s6-name' + (i + 1));
      el.textContent = L[i] ? L[i].f + ' (' + L[i].s + ')' : '';
      fitText(el, 0.5);
    }
  }
  ENTER.s6 = function () { renderLeaders(); refreshRasid().then(function () { if (S.current === 's6') renderLeaders(); }); };

  // ================================================================ شريحة 7: إضافة فائدة
  function doAddBenefit() {
    var title = $('s7-txtinoan').value.trim();
    var text = $('s7-txtfaidh').value.trim();
    if (!title || !text) return msg('اكتب عنوان الفائدة ونصّها قبل الإضافة');
    api('addBenefit', { name: S.user.name, title: title, text: text }, { busy: true }).then(function (r) {
      if (!r.ok) return msg(errText({ code: 'server', msg: r.msg }));
      if (r.item) {
        if (!r.item.f && S.user) r.item.f = S.user.fars;
        S.data.benefits.unshift(r.item); store('forsan.data', S.data);
      }
      $('s7-txtinoan').value = ''; $('s7-txtfaidh').value = '';
      msg('أُضيفت فائدتك بنجاح، جزاك الله خيرًا');
    }, function (e) { msg(errText(e)); });
  }

  // ================================================================ شريحة 9: فوائد الفرسان
  function makeList(box, items, label, selected, onPick, emptyText) {
    box.innerHTML = '';
    if (!items.length) {
      var em = document.createElement('div'); em.className = 'empty'; em.textContent = emptyText;
      box.appendChild(em); return;
    }
    items.forEach(function (it, i) {
      var d = document.createElement('div');
      d.className = 'item' + (selected === it ? ' sel' : '');
      d.setAttribute('role', 'option');
      d.textContent = label(it);
      d.addEventListener('click', function () {
        var all = box.querySelectorAll('.item');
        for (var k = 0; k < all.length; k++) all[k].classList.remove('sel');
        d.classList.add('sel');
        onPick(it);
      });
      box.appendChild(d);
    });
  }
  function showBenefit(b) {
    S.selBenefit = b;
    $('s9-TextBox1').textContent = b ? b.m : '';             // المشاركة (moshrkkh)
    $('s9-TextBox1').scrollTop = 0;
    $('s9-name1').textContent = b ? (b.f || b.n) : '';       // اسم الفارس (txtnamefars) لصاحب المشاركة
    $('s9-takiiim').textContent = b ? (b.k === '' || b.k == null ? 'لم تُقيَّم بعد' : b.k) : '';   // التقييم (takiim)
  }
  function renderBenefits() {
    var list = S.data.benefits || [];
    var sel = S.selBenefit && list.filter(function (b) { return b.id === S.selBenefit.id; })[0];
    makeList($('s9-Listmosharka'), list, function (b) { return b.t; }, sel, showBenefit,
      S.loaded ? 'لا توجد مشاركات بعد' : 'جارٍ التحميل…');
    showBenefit(sel || null);
  }
  ENTER.s9 = function () {
    S.selBenefit = null;
    renderBenefits();
    api('benefits').then(function (r) {
      if (r.ok && r.benefits) { S.data.benefits = r.benefits; store('forsan.data', S.data); if (S.current === 's9') renderBenefits(); }
    }).catch(function () { });
  };

  // ================================================================ شريحة 11: رصيدي
  function renderRasid() {
    var r = S.rasid || {};
    $('s11-r1').textContent = num(r.asilah);                                  // asilah
    $('s11-r2').textContent = num(r.takiimat) + num(r.takim2);                 // takiimat + takim2
    $('s11-r4').textContent = num(r.tahadi);                                   // tahadi (نقاط التحديات)
    $('s11-r3').textContent = num(r.asilah) + num(r.takiimat) + num(r.takim2) + num(r.tahadi); // majmo
  }
  ENTER.s11 = function () { renderRasid(); refreshRasid().then(function () { if (S.current === 's11') renderRasid(); }); };

  // ================================================================ شريحة 12 و 13: دروس المعلم
  function renderLessons() {
    var list = S.data.lessons || [];
    var sel = S.selLesson && list.filter(function (l) { return l.t === S.selLesson.t; })[0];
    S.selLesson = sel || null;
    makeList($('s12-Listdars'), list, function (l) { return l.t; }, sel, function (l) { S.selLesson = l; },
      S.loaded ? 'لا توجد دروس بعد' : 'جارٍ التحميل…');
  }
  ENTER.s12 = function () {
    S.selLesson = null;
    renderLessons();
    api('lessons').then(function (r) {
      if (r.ok && r.lessons) { S.data.lessons = r.lessons; store('forsan.data', S.data); if (S.current === 's12') renderLessons(); }
    }).catch(function () { });
  };
  function openLesson() {
    if (!S.selLesson) return msg('اختر عنوانا للاطلاع عليه');
    S.ismdars = S.selLesson.t;                               // المتغير ismdars
    go('s13');
  }
  ENTER.s13 = function () {
    var l = (S.data.lessons || []).filter(function (x) { return x.t === S.ismdars; })[0];
    $('s13-txtdars').textContent = l ? l.x : '';
    $('s13-txtdars').scrollTop = 0;
    $('s13-txtijabh').value = S.drafts[S.ismdars] || '';
  };
  $('s13-txtijabh').addEventListener('input', function () { S.drafts[S.ismdars] = this.value; });

  function doAnswer() {
    var text = $('s13-txtijabh').value.trim();
    if (!text) return msg('اكتب إجابتك أولًا ثم اضغط «أجب»');
    api('answer', { name: S.user.name, title: S.ismdars, text: text }, { busy: true }).then(function (r) {
      if (!r.ok) {
        if (r.code === 'evaluated') return msg('لقد قيَّم المعلم إجابتك');
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      msg('أُرسلت إجابتك إلى المعلم بنجاح');
    }, function (e) { msg(errText(e)); });
  }

  // ================================================================ تحدي الفرسان (شرائح 14 – 17)
  //  s14 أسماء الفرسان النشطين ← s15 لوحة التحدي (الشريطان) ← s16 سؤال التحدي — و s17 الفائزون
  //  التطبيق يسأل قاعدة البيانات كل بضع ثوانٍ: «من النشطون؟ هل وصلتني دعوة؟» (lobby)
  //  وأثناء التحدي كل ثانية ونصف: «ما حالة التحدي الآن؟» (game)
  var CH_POLL = 1500, CH_POLL_WAIT = 600, LOBBY_SLOW = 5000, LOBBY_FAST = 2500, VERDICT_MS = 1100;
  var LB = { timer: 0, inFlight: false, list: null, sel: null, selF: '', out: null, inv: null, seen: {}, gone: {}, winners: null };
  var G = null;                                   // التحدي الجاري
  function noop() { }

  // ---------- سؤال بجوابين (نعم / لا) وتنبيه قصير
  var ASK = { open: false, tag: '', onYes: null, onNo: null };
  function ask(text, o) {
    o = o || {};
    ASK.open = true; ASK.tag = o.tag || ''; ASK.onYes = o.onYes || null; ASK.onNo = o.onNo || null;
    $('ask-text').textContent = text;
    $('ask-yes').textContent = o.yes || 'نعم';
    $('ask-yes').hidden = o.yes === null;
    $('ask-no').textContent = o.no || 'لا';
    $('ask').hidden = false;
    var a = typingEl(); if (a) a.blur();
  }
  function closeAsk() {
    ASK.open = false; ASK.tag = ''; ASK.onYes = ASK.onNo = null;
    $('ask').hidden = true;
  }
  function askAnswer(yes) {
    var f = yes ? ASK.onYes : ASK.onNo;
    closeAsk();
    if (f) f();
  }
  $('ask-yes').addEventListener('click', function (e) { e.stopPropagation(); askAnswer(true); });
  $('ask-no').addEventListener('click', function (e) { e.stopPropagation(); askAnswer(false); });

  var toastTimer = 0;
  function toast(text, ms) {
    var el = $('toast');
    el.textContent = text;
    el.hidden = true; void el.offsetWidth; el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, ms || 4500);
  }

  // ---------- صيغ العدد
  function points(n) { return n === 1 ? 'نقطة واحدة' : n === 2 ? 'نقطتان' : (n >= 3 && n <= 10 ? n + ' نقاط' : n + ' نقطة'); }
  function times(n) { return n === 1 ? 'مرة واحدة' : n === 2 ? 'مرتين' : (n >= 3 && n <= 10 ? n + ' مرات' : n + ' مرة'); }

  // ---------- الحضور والدعوات (lobby)
  function lobbySoon(ms) { clearTimeout(LB.timer); LB.timer = setTimeout(lobbyTick, ms); }
  function lobbyTick() {
    clearTimeout(LB.timer);
    if (!S.user || G || !/^https:\/\//.test(API)) return;
    if (document.hidden) return;                  // يُستأنف عند العودة إلى التطبيق
    if (LB.inFlight) return;
    LB.inFlight = true;
    var who = S.user.name, onList = S.current === 's14';
    api('lobby', { name: who, list: onList ? 1 : 0 }).then(function (r) {
      if (S.user && S.user.name === who && r.ok) applyLobby(r, onList);
    }, noop).then(function () {
      LB.inFlight = false;
      if (!S.user || G) return;
      if (LB.out && Date.now() - LB.out.t > 40000) inviteTimedOut();   // لم يصل رد خلال 40 ثانية
      lobbySoon(S.current === 's14' || LB.out || ASK.tag === 'invite' ? LOBBY_FAST : LOBBY_SLOW);
    });
  }
  function inviteTimedOut() {
    var o = LB.out; LB.out = null;
    if (ASK.tag === 'wait') closeAsk();
    api('cancelInvite', { name: S.user.name, id: o.id }).then(function (r) {
      if (r.ok && r.game) joinGame(r.game);
      else msg('لم يرد الفارس ' + o.tf + ' على دعوتك، جرّب مرة أخرى أو اختر فارسًا آخر');
    }, function () { msg('لم يرد الفارس ' + o.tf + ' على دعوتك، جرّب مرة أخرى أو اختر فارسًا آخر'); });
  }

  function applyLobby(r, withList) {
    if (G) return;
    if (r.game && !LB.gone[r.game.id]) { joinGame(r.game); return; }
    // نتيجة دعوتي
    if (LB.out && r.out && r.out.id === LB.out.id && r.out.st !== 'p') {
      var tf = LB.out.tf; LB.out = null;
      if (ASK.tag === 'wait') closeAsk();
      if (r.out.st === 'y' && r.out.g) { if (!LB.gone[r.out.g]) joinGame(r.out.g); return; }
      if (r.out.st === 'n') msg('اعتذر الفارس ' + tf + ' عن التحدي');
      else msg('لم يرد الفارس ' + tf + ' على دعوتك، جرّب مرة أخرى أو اختر فارسًا آخر');
    }
    // دعوة وصلتني
    if (r.inv && !LB.seen[r.inv.id]) {
      LB.seen[r.inv.id] = 1;
      LB.inv = r.inv;
      showInvite(r.inv);
    } else if (!r.inv && LB.inv && ASK.tag === 'invite') {
      LB.inv = null;
      closeAsk();
      toast('أُلغيت الدعوة أو انتهت مهلتها');
    }
    if (withList && r.list) { LB.list = r.list; if (S.current === 's14') renderActive(); }
  }

  function showInvite(inv) {
    if (S.current === 's5') hideVerdict();
    ask('الفارس ' + inv.f + ' يريد أن يتحداك، فهل أنت موافق؟', {
      tag: 'invite',
      onYes: function () { replyInvite(inv, true); },
      onNo: function () { replyInvite(inv, false); }
    });
    lobbySoon(LOBBY_FAST);
  }
  function replyInvite(inv, yes) {
    LB.inv = null;
    api('reply', { name: S.user.name, id: inv.id, yes: yes ? 1 : 0 }, { busy: yes }).then(function (r) {
      if (!yes) return;
      if (r.ok && r.game) { joinGame(r.game); return; }
      if (r.code === 'expired' || r.code === 'gone') msg('انتهت مهلة الدعوة، أو ألغاها صاحبها');
      else if (r.code === 'busy') msg('أنت في تحدٍّ آخر الآن');
      else msg(errText({ code: 'server', msg: r.msg }));
    }, function (e) { if (yes) msg(errText(e)); });
  }

  // ---------- شريحة 14: أسماء الفرسان النشطين
  function renderActive() {
    var box = $('s14-list'), list = LB.list;
    if (LB.sel && !(list || []).some(function (k) { return k.n === LB.sel && !k.b; })) LB.sel = null;
    box.innerHTML = '';
    if (!list || !list.length) {
      var em = document.createElement('div'); em.className = 'empty';
      em.textContent = list ? 'لا يوجد فرسان نشطون الآن\nانتظر قليلًا حتى يفتح أصدقاؤك التطبيق' : 'جارٍ البحث عن الفرسان النشطين…';
      box.appendChild(em); return;
    }
    list.forEach(function (k) {
      var d = document.createElement('div');
      d.className = 'item' + (k.b ? ' busy' : '') + (LB.sel === k.n ? ' sel' : '');
      d.setAttribute('role', 'option');
      var nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = k.f;
      d.appendChild(nm);
      if (k.b) { var tg = document.createElement('span'); tg.className = 'tag'; tg.textContent = 'في تحدٍّ'; d.appendChild(tg); }
      d.addEventListener('click', function () {
        if (k.b) return toast('الفارس ' + k.f + ' في تحدٍّ الآن');
        LB.sel = k.n; LB.selF = k.f;
        renderActive();
      });
      box.appendChild(d);
    });
  }
  ENTER.s14 = function () {
    LB.sel = null;
    renderActive();
    lobbyTick();
  };

  function doInvite() {
    if (!LB.sel) return msg('اختر اسم الفارس الذي تريد أن تتحداه');
    var to = LB.sel, tf = LB.selF;
    api('invite', { name: S.user.name, to: to }, { busy: true }).then(function (r) {
      if (r.ok && r.game) { joinGame(r.game); return; }          // كان قد دعاك قبل قليل
      if (!r.ok) {
        if (r.code === 'offline') return msg('الفارس ' + tf + ' لم يعد نشطًا الآن');
        if (r.code === 'busy') return msg('الفارس ' + tf + ' مشغول بتحدٍّ آخر، انتظر قليلًا أو اختر غيره');
        if (r.code === 'invited') return msg('وصلت الفارسَ ' + tf + ' دعوةٌ أخرى الآن، حاول بعد قليل');
        if (r.code === 'self') return msg('لا يمكنك أن تتحدى نفسك! اختر فارسًا آخر');
        if (r.code === 'hasinv') { lobbySoon(100); return msg('وصلتك دعوة من فارس آخر، أجب عنها أولًا'); }
        return msg(errText({ code: 'server', msg: r.msg }));
      }
      LB.out = { id: r.id, tf: r.tf || tf, t: Date.now() };
      ask('أُرسلت الدعوة إلى الفارس ' + LB.out.tf + '\nبانتظار موافقته…', {
        tag: 'wait', yes: null, no: 'إلغاء الدعوة',
        onNo: function () {
          var o = LB.out; LB.out = null;
          if (o) api('cancelInvite', { name: S.user.name, id: o.id }).then(function (r) {
            if (r.ok && r.game) joinGame(r.game);       // كان قد وافق قبل الإلغاء بلحظة
          }, noop);
        }
      });
      lobbySoon(LOBBY_FAST);
    }, function (e) { msg(errText(e)); });
  }

  // ---------- الدخول في التحدي والخروج منه
  function joinGame(g) {
    var id = typeof g === 'string' ? g : g.id;
    if (G && G.id === id) { if (typeof g !== 'string') applyGame(g); return; }
    if (G) stopGame(G);
    if (ASK.open) closeAsk();
    LB.out = null; LB.inv = null;
    clearTimeout(LB.timer);
    if (S.current === 's5') { hideVerdict(); saveQuizIfBetter(); S.quiz.dirty = false; }
    G = { id: id, seq: -1, st: null, qShown: null, lastShown: null, msgSeen: null, over: false,
          poll: 0, inFlight: false, tick: 0, vt: 0, verdict: false, answered: null, qEnd: 0, pending: null };
    $('s15-chat').innerHTML = '';
    $('s15-rsala').value = '';
    renderBoard(null);
    go('s15');
    if (typeof g !== 'string') applyGame(g);
    gamePoll();
  }
  function stopGame(g) {
    clearTimeout(g.poll); clearInterval(g.tick); clearTimeout(g.vt); clearInterval(g.cd);
    $('s16-picsah').classList.remove('show'); $('s16-pickata').classList.remove('show');
  }
  function exitGame(to) {
    var g = G;
    if (ASK.open && ASK.tag !== 'invite') closeAsk();
    if (g) {
      G = null;
      stopGame(g);
      LB.gone[g.id] = 1;                         // لا نعود إليه وإن ذكره الخادم قبل أن يصله خروجنا
      var tries = 0, who = S.user.name;
      (function leave() {
        api('leave', { name: who, id: g.id }).then(function () { lobbySoon(300); }, function () {
          if (tries++ < 3) setTimeout(leave, 1500); else lobbySoon(300);
        });
      })();
    } else lobbySoon(400);
    go(to);
  }
  function gameGone() {
    var g = G; G = null;
    if (g) stopGame(g);
    if (ASK.open) closeAsk();
    msg('انتهى هذا التحدي');
    go('s14');
    lobbySoon(400);
  }

  function gamePoll() {
    var mine = G;
    if (!mine) return;
    clearTimeout(mine.poll);
    if (mine.inFlight) return;
    if (document.hidden) { mine.poll = setTimeout(gamePoll, CH_POLL); return; }
    mine.inFlight = true;
    api('game', { name: S.user.name, id: mine.id }).then(function (r) {
      if (G !== mine) return;
      if (r.ok && r.game) { mine.fails = 0; applyGame(r.game); }
      else if (r.code === 'nogame') gameGone();
      else netFail(mine);
    }, function () { if (G === mine) netFail(mine); }).then(function () {
      mine.inFlight = false;
      if (G !== mine) return;
      var st = mine.st, waiting = st && st.ph !== 'over' && st.turn !== st.me;
      mine.poll = setTimeout(gamePoll, waiting ? CH_POLL_WAIT : CH_POLL);
    });
  }

  function netFail(mine) {
    mine.fails = (mine.fails || 0) + 1;
    if (mine.fails === 5) toast('الاتصال بالإنترنت ضعيف… نحاول من جديد', 5000);
  }

  // حالة جديدة من قاعدة البيانات
  function applyGame(g) {
    if (!G || !g || g.id !== G.id || g.seq < G.seq) return;
    G.seq = g.seq; G.st = g;
    if (G.lastShown === null) {                  // أول حالة: لا نعيد عرض ما مضى
      G.lastShown = g.last ? g.last.seq : 0;
      G.msgSeen = (g.msgs || []).reduce(function (m, x) { return Math.max(m, x.i); }, 0);
    }
    newMessages(g);
    if (g.last && g.last.seq > G.lastShown) {
      G.lastShown = g.last.seq;
      // نتيجتي ظهرت لحظة ضغطي على الجواب، فلا تتكرر — إلا إذا احتسبها الخادم على غير ما ظهر
      if (!(g.last.by === g.me && G.answered === g.last.qid)) chResult(g.last.ok);
      else if (G.shown && G.shown.qid === g.last.qid && G.shown.ok !== g.last.ok) {
        play(g.last.ok ? 'sotsah' : 'sotkat');
        toast(g.last.ok ? 'احتُسب جوابك صحيحًا' : 'وصل جوابك بعد انتهاء الوقت، فاحتُسب خطأ', 5000);
      }
    }
    route(g);
    if (!G || G.st !== g) return;
    if (g.ph === 'over') overUpdate(g);
    if (g.next && G) joinGame(g.next);           // وافق الاثنان على مباراة جديدة
  }

  function route(g) {
    if (G.verdict) return;                       // ننتظر حتى تختفي صورة الصح/الخطأ
    if (g.ph === 'q' && g.q) {
      if (G.qShown === g.q.id) { if (S.current !== 's16') go('s16'); return; }
      var at = serverToLocal(g.q.at);
      if (Date.now() < at - 40) { countdown(g, at); return; }   // لم تحن لحظة الظهور بعد
      clearInterval(G.cd); G.cdq = null;
      G.qShown = g.q.id;
      go('s16');
      showChQuestion(g);
    } else {
      clearInterval(G.tick); clearInterval(G.cd); G.cdq = null;
      if (S.current === 's16') go('s15');
      renderBoard(g);
    }
  }
  // «يظهر السؤال بعد 3، 2، 1» على لوحة التحدي عند الفارسين
  function countdown(g, at) {
    if (G.cdq === g.q.id) return;                 // العدّ جارٍ لهذا السؤال
    G.cdq = g.q.id;
    if (S.current !== 's15') go('s15');
    $('s15-strttahadi').classList.add('disabled');
    var dor = $('s15-dor'), mine = G;
    dor.classList.add('myturn');
    function tick() {
      if (G !== mine || G.cdq !== g.q.id) { clearInterval(mine.cd); return; }
      var left = at - Date.now();
      if (left <= 40) { clearInterval(G.cd); G.cdq = null; dor.classList.remove('myturn'); route(G.st); return; }
      var t = 'يظهر السؤال بعد ' + Math.ceil(left / 1000);
      if (dor.textContent !== t) { dor.textContent = t; fitText(dor, 0.45); }
    }
    clearInterval(G.cd);
    G.cd = setInterval(tick, 50);
    tick();
  }

  // ---------- شريحة 15: لوحة التحدي
  function renderBoard(g) {
    for (var i = 0; i < 2; i++) {
      var n = $('s15-n' + (i + 1)), bar = $('s15-bar' + (i + 1)).children;
      n.querySelector('.nm').textContent = g ? g.f[i] + (i === g.me ? ' (أنت)' : '') : '';
      n.querySelector('.st').textContent = g ? g.s[i] + ' / 10' : '';
      n.classList.toggle('on', !!g && g.ph !== 'over' && g.turn === i);
      for (var j = 0; j < bar.length; j++) {
        var on = !!g && j < g.s[i], was = bar[j].classList.contains('on');
        bar[j].classList.toggle('on', on);
        bar[j].classList.toggle('new', on && !was);
      }
    }
    var dor = $('s15-dor');
    if (!g) dor.textContent = '';
    else if (g.ph === 'over') dor.textContent = g.win === g.me ? 'مبارك! أنت الفائز' : 'الفائز: ' + g.f[g.win];
    else dor.textContent = g.turn === g.me ? 'دورك الآن يا ' + g.f[g.me] : 'دور الفارس ' + g.f[g.turn];
    dor.classList.toggle('myturn', !!g && g.ph !== 'over' && g.turn === g.me);
    if (S.current === 's15') { fitText(dor, 0.45); fitText($('s15-n1'), 0.6); fitText($('s15-n2'), 0.6); }
    // زر «ابدا التحدي» غير فعال عند من ليس دوره
    $('s15-strttahadi').classList.toggle('disabled', !(g && g.ph === 'board' && g.turn === g.me));
  }

  function doStart() {
    var g = G && G.st;
    if (!g || g.ph !== 'board' || g.turn !== g.me) return;
    var mine = G;
    $('s15-strttahadi').classList.add('disabled');
    $('s15-dor').textContent = 'استعدّ…';
    fitText($('s15-dor'), 0.45);
    api('start', { name: S.user.name, id: mine.id }).then(function (r) {
      if (G !== mine) return;
      if (r.ok && r.game) return applyGame(r.game);
      renderBoard(G.st);
      if (r.code === 'noq') msg('لا توجد أسئلة بعد، انتظر حتى يضيفها المعلم');
      else if (r.code === 'nogame') gameGone();
      else msg(errText({ code: 'server', msg: r.msg }));
    }, function (e) { if (G === mine) { renderBoard(G.st); msg(errText(e)); } });
  }

  // ---------- الرسائل
  function newMessages(g) {
    (g.msgs || []).forEach(function (m) {
      if (m.i > G.msgSeen) {
        G.msgSeen = m.i;
        if (m.by !== g.me) { G.fresh = m.i; if (S.current !== 's15') toast('رسالة من ' + g.f[m.by] + ':\n' + m.x, 6000); }
      }
      if (G.pending && m.by === g.me && m.x === G.pending) G.pending = null;
    });
    renderChat(g);
  }
  function renderChat(g) {
    var box = $('s15-chat');
    box.innerHTML = '';
    var list = (g && g.msgs || []).slice(-2).map(function (m) { return { me: m.by === g.me, who: m.by === g.me ? 'أنت' : g.f[m.by], x: m.x, i: m.i }; });
    if (G && G.pending) list.push({ me: true, who: 'أنت', x: G.pending, wait: true });
    list.slice(-2).forEach(function (m) {
      var d = document.createElement('div');
      d.className = 'm ' + (m.me ? 'me' : 'fr') + (m.wait ? ' wait' : '') + (!m.me && G && m.i === G.fresh ? ' fresh' : '');
      d.textContent = m.who + ': ' + m.x;
      box.appendChild(d);
    });
    if (G) G.fresh = 0;
  }
  function sendChatMsg() {
    var el = $('s15-rsala');
    var text = el.value.replace(/\s+/g, ' ').trim();
    if (!text) return msg('اكتب رسالتك لصديقك أولًا');
    if (!G) return;
    var mine = G;
    el.value = ''; el.blur();
    mine.pending = text;
    if (mine.st) renderChat(mine.st);
    api('msg', { name: S.user.name, id: mine.id, text: text }).then(function (r) {
      if (G !== mine) return;
      if (r.ok && r.game) return applyGame(r.game);
      mine.pending = null; if (mine.st) renderChat(mine.st);
      if (!el.value) el.value = text;
      msg(r.code === 'nogame' ? 'انتهى هذا التحدي' : 'لم تُرسَل الرسالة، حاول مرة أخرى');
    }, function (e) {
      if (G !== mine) return;
      mine.pending = null; if (mine.st) renderChat(mine.st);
      if (!el.value) el.value = text;
      msg(errText(e));
    });
  }
  // زر الإدخال في لوحة المفاتيح يرسل الرسالة
  $('s15-rsala').addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMsg(); }
  });
  $('s15-rsala').addEventListener('beforeinput', function (e) {
    if (e.inputType === 'insertLineBreak' || e.inputType === 'insertParagraph') { e.preventDefault(); sendChatMsg(); }
  });

  // ---------- شريحة 16: سؤال التحدي (أوامر شاشة الأسئلة نفسها وأصواتها، مع عداد الوقت)
  function showChQuestion(g) {
    var q = g.q, mine = g.turn === g.me;
    G.answered = null;
    $('s16-picsah').classList.remove('show'); $('s16-pickata').classList.remove('show');
    var el = $('s16-sss1');
    el.innerHTML = '';
    var d = document.createElement('div'); d.className = 'qin'; d.textContent = q.t;
    el.appendChild(d);
    fitText(el, 0.6); el.scrollTop = 0;
    for (var k = 0; k < 3; k++) {
      var a = $('s16-j' + (k + 1));
      a.textContent = q.a[k] || '';
      a.classList.toggle('locked', !mine);       // لا يجيب إلا صاحب الدور
      a.classList.remove('wait');
      fitText(a, 0.5);
    }
    var dor = $('s16-dor');
    dor.textContent = mine ? 'أجب يا ' + g.f[g.me] : 'يجيب الفارس ' + g.f[g.turn];
    fitText(dor, 0.5);
    G.qEnd = q.end ? serverToLocal(q.end) : Date.now() + Math.max(0, Math.min(10000, q.left));
    G.revealedAt = Date.now();
    clearInterval(G.tick);
    G.tick = setInterval(timerTick, 200);
    timerTick();
  }
  function timerTick() {
    var g = G && G.st;
    if (!g || g.ph !== 'q' || !g.q) { if (G) clearInterval(G.tick); return; }
    var left = Math.max(0, Math.min(10, Math.ceil((G.qEnd - Date.now()) / 1000)));
    var el = $('s16-wakt');
    if (el.textContent !== String(left)) el.textContent = left;
    el.classList.toggle('low', left > 0 && left <= 3);
    if (left === 0) {
      clearInterval(G.tick);
      if (g.turn === g.me && G.answered !== g.q.id) sendChAnswer(-1);   // انتهى الوقت = جواب خطأ
    }
  }
  function onChAnswer(el) {
    var g = G && G.st;
    if (!g || g.ph !== 'q' || !g.q || g.turn !== g.me || G.answered === g.q.id || G.verdict) return;
    sendChAnswer(+el.getAttribute('data-i'));
  }
  function sendChAnswer(k) {
    var g = G.st, q = g.q, mine = G;
    mine.answered = q.id;
    clearInterval(mine.tick);
    var right = ((q.x - q.id) % 3 + 3) % 3;
    mine.shown = { qid: q.id, ok: k === right };
    chResult(mine.shown.ok);                      // الصورة والصوت فورًا كما في شاشة الأسئلة
    var tries = 0;
    (function send() {
      api('ans', { name: S.user.name, id: mine.id, q: q.id, k: k }).then(function (r) {
        if (G !== mine) return;
        if (r.ok && r.game) applyGame(r.game);
        else if (r.code !== 'nogame' && tries++ < 3) setTimeout(send, 800);   // الخادم مشغول: نعيد الإرسال
      }, function () { if (G === mine && tries++ < 3) setTimeout(send, 800); });
    })();
  }
  function chResult(ok) {
    play(ok ? 'sotsah' : 'sotkat');
    if (S.current !== 's16' || !G) return;
    var mine = G;
    G.verdict = true;
    for (var k = 1; k <= 3; k++) $('s16-j' + k).classList.add('locked');
    $('s16-picsah').classList.remove('show'); $('s16-pickata').classList.remove('show');
    void $('s16-picsah').offsetWidth;
    $(ok ? 's16-picsah' : 's16-pickata').classList.add('show');
    clearTimeout(G.vt);
    G.vt = setTimeout(function () {
      if (G !== mine) return;
      $('s16-picsah').classList.remove('show'); $('s16-pickata').classList.remove('show');
      G.verdict = false;
      if (G.st) { route(G.st); if (G && G.st && G.st.ph === 'over') overUpdate(G.st); }
    }, VERDICT_MS);
  }

  // ---------- نهاية التحدي: رسالة الفوز، ثم «هل ترغب في مباراة جديدة؟»
  function overUpdate(g) {
    if (G.verdict) return;
    var me = g.me, other = 1 - me, won = g.win === me, who = g.f[other];
    if (!G.over) {
      G.over = true; G.stage = 1;                 // 1 = رسالة النتيجة ظاهرة، 2 = بعد إغلاقها
      clearInterval(G.tick);
      var t;
      if (won && g.why === 'full') t = 'مبارك يا ' + g.f[me] + '! فزت في التحدي\nوأُضيفت إلى رصيدك ' + points(g.pts);
      else if (won) t = (g.why === 'leave' ? 'انسحب الفارس ' + who + ' من التحدي' : 'انقطع اتصال الفارس ' + who) +
        '، فالفوز لك' + (g.pts > 0 ? '\nوأُضيفت إلى رصيدك ' + points(g.pts) : '');
      else if (g.why === 'full') t = 'فاز الفارس ' + who + ' في هذا التحدي\nحظًّا أوفر في المرة القادمة';
      else if (g.why === 'leave') t = 'انسحبتَ من هذا التحدي، فاحتُسب الفوز للفارس ' + who;
      else t = 'انقطع اتصالك مدة طويلة، فاحتُسب الفوز للفارس ' + who;
      if (won) play('sotsah');
      if (won && S.rasid) { S.rasid.tahadi = num(S.rasid.tahadi) + g.pts; }
      var mine = G;
      msg(t).then(function () {
        if (G !== mine) return;
        G.stage = 2;
        var st = G.st;
        if (st.next) return;
        if (st.why !== 'full') { exitGame('s14'); return; }
        if (st.re[1 - st.me] === 'n') { msg('اعتذر صديقك عن دور آخر'); exitGame('s14'); return; }
        askRematch();
      });
      return;
    }
    if (G.stage < 2 || g.next) return;
    // تحديثات أثناء السؤال عن مباراة جديدة أو انتظار الرد
    if (g.re[other] === 'y' && ASK.tag === 'rematch') $('ask-text').textContent = 'يرغب صديقك في دور آخر، فهل توافق؟';
    if (g.re[other] === 'n') {                    // اعتذر صديقه (أيًّا كانت النافذة الظاهرة)
      msg('اعتذر صديقك عن دور آخر');
      exitGame('s14');
    }
  }
  function askRematch() {
    var st = G.st;
    ask(st.re[1 - st.me] === 'y' ? 'يرغب صديقك في دور آخر، فهل توافق؟' : 'هل ترغب في مباراة جديدة؟', {
      tag: 'rematch',
      onYes: sendRematch,
      onNo: function () { exitGame('s14'); }      // يعود لشاشة الفرسان النشطين لتحدي فارس جديد
    });
  }
  function sendRematch() {
    var mine = G;
    if (!mine) return;
    api('rematch', { name: S.user.name, id: mine.id, yes: 1 }, { busy: true }).then(function (r) {
      if (G !== mine) return;
      if (r.ok && r.game) applyGame(r.game);
      if (G === mine && !(G.st && G.st.next) && !(G.st && G.st.re[1 - G.st.me] === 'n')) {
        ask('بانتظار رد صديقك…', { tag: 'rewait', yes: null, no: 'إلغاء', onNo: function () { exitGame('s14'); } });
      }
    }, function (e) { if (G === mine) { msg(errText(e)).then(function () { if (G === mine) askRematch(); }); } });
  }

  // زر «عودة» في لوحة التحدي: يعود إلى الشاشة الرئيسية (مع تأكيد الانسحاب إن لم ينته التحدي)
  function chBack() {
    var g = G && G.st;
    if (!G) { go('s4'); return; }
    if (g && g.ph === 'over') { exitGame('s4'); return; }
    ask('هل تريد الانسحاب من التحدي؟\nسيُحتسب الفوز لصديقك', { tag: 'quit', onYes: function () { exitGame('s4'); } });
  }

  // ---------- شريحة 17: الفائزون في التحديات
  function renderWinners() {
    var r = LB.winners, box = $('s17-list');
    box.innerHTML = '';
    if (!r || !r.list.length) {
      var em = document.createElement('div'); em.className = 'empty';
      em.textContent = r ? 'لم يفز أحد في التحديات بعد\nكن أول الفائزين!' : 'جارٍ التحميل…';
      box.appendChild(em);
    } else {
      r.list.forEach(function (w, i) {
        var row = document.createElement('div');
        row.className = 'row r' + (i + 1) + (w.me ? ' me' : '');
        var rk = document.createElement('span'); rk.className = 'rk'; rk.textContent = i + 1;
        var nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = w.f;
        var ws = document.createElement('span'); ws.className = 'w'; ws.textContent = 'فاز ' + times(w.w);
        row.appendChild(rk); row.appendChild(nm); row.appendChild(ws);
        box.appendChild(row);
      });
    }
    var m = r && r.mine;
    $('s17-mine').textContent = m ? (m.w ? 'فزتَ ' + times(m.w) + '، ونقاطك من التحديات: ' + m.p : 'لم تفز في تحدٍّ بعد، ابدأ أول تحدٍّ لك!') : '';
    if (S.current === 's17') fitText($('s17-mine'), 0.6);
  }
  ENTER.s17 = function () {
    renderWinners();
    api('winners', { name: S.user ? S.user.name : '' }).then(function (r) {
      if (r.ok) { LB.winners = r; if (S.current === 's17') renderWinners(); }
    }).catch(noop);
  };

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) return;
    if (G) gamePoll(); else lobbyTick();
  });

  // ---------------------------------------------------------------- ربط الأزرار
  function to(id) { return function () { go(id); }; }
  var ACTIONS = {
    s1: { dokol: to('s2'), enshahesab: to('s3'), koroj: exitApp },
    s2: { dokol: doLogin, aodah: to('s1') },
    s3: { cmdnew: doRegister, aodah: to('s1') },
    s4: {
      addfaidh: to('s7'), afdal: to('s6'), faoaid: to('s9'), ziadh: to('s5'),
      doros: to('s12'), rasidy: to('s11'), aodah: logout, koroj: function () { saveQuizIfBetter(); exitApp(); },
      tahdi: to('s14'), faizon: to('s17')
    },
    s5: { answer: onAnswer, aodah: quizBack },
    s6: { aodah: to('s4') },
    s7: { edafh: doAddBenefit, aodah: to('s4') },
    s9: { aodah: to('s4') },
    s11: { aodah: to('s4') },
    s12: { istirad: openLesson, aodah: to('s4') },
    s13: { ajb: doAnswer, aodah: to('s4') },
    s14: { invite: doInvite, aodah: to('s4') },
    s15: { strttahadi: doStart, ersal: sendChatMsg, aodah: chBack },
    s16: { chans: onChAnswer, aodah: chBack },                 // لا زر عودة ظاهر في شاشة سؤال التحدي، وزر الرجوع في الجوال يسأل عن الانسحاب
    s17: { aodah: to('s4') }
  };

  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!t || S.busy || msgOpen || ASK.open) return;
    var scr = t.closest('.screen');
    if (!scr || scr.id !== S.current) return;
    var act = t.getAttribute('data-act');
    var now = Date.now();
    if (act !== 'answer' && act !== 'chans') {               // منع الضغط المزدوج على الأزرار
      if (now - S.lastTap < 350) return;
      S.lastTap = now;
    }
    var fn = ACTIONS[scr.id] && ACTIONS[scr.id][act];
    if (fn) fn(t);
  });

  // زر الرجوع في الجوال يعمل عمل زر «عودة» في كل شاشة
  window.androidBack = function () {
    if (msgOpen) { closeMsg(); return; }
    if (ASK.open) { if (!$('ask-no').hidden) askAnswer(false); return; }
    if (S.busy) return;
    if (S.current === 's1') { exitApp(); return; }
    var fn = ACTIONS[S.current] && ACTIONS[S.current].aodah;
    if (fn) fn();
  };

  // ---------------------------------------------------------------- البدء
  function start() {
    measure();
    go('s1');
    boot();
    setTimeout(measure, 300);
    setTimeout(measure, 1200);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { refitCurrent(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();

  // للاختبار فقط
  window.__forsan = { S: S, go: go, G: function () { return G; }, LB: LB };
})();
