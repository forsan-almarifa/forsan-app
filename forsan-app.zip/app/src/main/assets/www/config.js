// رابط سكربت قاعدة البيانات forsan (Google Apps Script)
// يُكتب تلقائيًا أثناء البناء على GitHub من الملف api-url.txt — لا حاجة لتعديله هنا.
window.FORSAN_API = "__FORSAN_API_URL__";
