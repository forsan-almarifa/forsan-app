package com.forsan.almarifa;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * فرسان المعرفة — الشاشة الوحيدة في التطبيق.
 * تعرض واجهة التطبيق (assets/www) بملء الشاشة، بالطول دائمًا.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/www/index.html";

    private WebView web;
    private int lastKeyboard = -1;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            // يمتد التطبيق تحت النتوء (الكاميرا) في أعلى الشاشة
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(lp);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(241, 240, 225));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);                 // لا يتأثر التصميم بتكبير الخط في إعدادات الجوال
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serveAsset(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOST.equals(request.getUrl().getHost());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !HOST.equals(Uri.parse(url).getHost());
            }

            // إن أغلق النظام محرك العرض لقلة الذاكرة، نعيد فتح الشاشة بدل أن يتوقف التطبيق
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                if (web != null) {
                    web.destroy();
                    web = null;
                }
                recreate();
                return true;
            }
        });

        setContentView(web);
        watchKeyboard();
        hideSystemBars();
        web.loadUrl(START_URL);
    }

    // ---------------------------------------------------------------- ملء الشاشة
    private void hideSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    // ---------------------------------------------------------------- لوحة المفاتيح
    // نخبر الواجهة بارتفاع لوحة المفاتيح لترفع الخانة التي يكتب فيها الطالب فوقها
    private void watchKeyboard() {
        final View root = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    reportKeyboard(insets.getInsets(WindowInsets.Type.ime()).bottom);
                    return v.onApplyWindowInsets(insets);
                }
            });
        } else {
            root.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    Rect r = new Rect();
                    root.getWindowVisibleDisplayFrame(r);
                    int full = root.getRootView().getHeight();
                    int kb = full - r.bottom;
                    if (kb < full * 0.15) kb = 0;   // شريط التنقل وليس لوحة مفاتيح
                    reportKeyboard(kb);
                }
            });
        }
    }

    private void reportKeyboard(int px) {
        if (px == lastKeyboard || web == null) return;
        lastKeyboard = px;
        float density = getResources().getDisplayMetrics().density;
        final int cssPx = Math.round(px / density);
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("window.__forsanKeyboard&&window.__forsanKeyboard(" + cssPx + ")", null);
            }
        });
    }

    // ---------------------------------------------------------------- زر الرجوع
    @SuppressWarnings("deprecation")
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (web == null) { finish(); return; }
        // يعمل زر الرجوع عمل زر «عودة» في الشاشة الحالية
        web.evaluateJavascript("window.androidBack?(window.androidBack(),'ok'):'none'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"\"ok\"".equals(value)) finish();
            }
        });
    }

    // ---------------------------------------------------------------- ملفات الواجهة من داخل التطبيق
    private WebResourceResponse serveAsset(Uri uri) {
        if (uri == null || !"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost())) return null;
        String path = uri.getPath();
        if (path == null || !path.startsWith("/www/") || path.contains("..")) return null;
        String asset = path.substring(1);
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-cache");
        String mime = mimeOf(asset);
        try {
            InputStream in = getAssets().open(asset);
            String enc = (mime.startsWith("text/") || mime.endsWith("javascript") || mime.endsWith("json")) ? "utf-8" : null;
            return new WebResourceResponse(mime, enc, 200, "OK", headers, in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers,
                    new ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html")) return "text/html";
        if (n.endsWith(".js")) return "application/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".ttf")) return "font/ttf";
        if (n.endsWith(".wav")) return "audio/wav";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        return "application/octet-stream";
    }

    // ---------------------------------------------------------------- جسر بين الواجهة وأندرويد
    private class Bridge {
        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finishAndRemoveTask();
                }
            });
        }
    }

    // ---------------------------------------------------------------- دورة حياة الشاشة
    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
